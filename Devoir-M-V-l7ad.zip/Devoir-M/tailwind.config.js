module.exports = {
    content: ["./templates/Sales_Product.html", "./templates/Add_products.html", "./templates/Add_sales.html", "./templates/HomePage.html", "./templates/Totals_Sales.html", "./templates/Update_Product.html"],
    theme: {
        extend: {},
    },
    plugins: [],
}