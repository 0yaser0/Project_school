from flask import Blueprint, jsonify, render_template, request,redirect, url_for
from datetime import datetime
from DB import mysql

bp = Blueprint('routes', __name__)

products = {}
Sales_Product = {}

def calculate_Totals_Sales():
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT s.date, p.prodPrice, s.quantity
        FROM products_db.sales s
        INNER JOIN products_db.product p ON p.id = s.product_id
    """)
    sales_data = cur.fetchall()
    Totals_Sales = {}
    for date, price, quantity in sales_data:
        if date not in Totals_Sales:
            Totals_Sales[date] = 0
        Totals_Sales[date] += price * quantity
    cur.close()
    return Totals_Sales


@bp.route('/')
def HomePage():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM product")
    mysql.connection.commit()
    fetchdata = cur.fetchall()
    cur.close()
    return render_template('HomePage.html', data=fetchdata)

@bp.route('/add', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        prodName = request.form.get('name')
        prodDesc = request.form.get('description')
        prodPrice = request.form.get('price')
        prodInStock = request.form.get('quantity')
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO product (prodName, prodDesc, prodPrice, prodInStock) VALUES (%s, %s, %s, %s)", (prodName, prodDesc, prodPrice, prodInStock))
        mysql.connection.commit()
        cur.execute("SELECT * FROM product")  
        products = cur.fetchall() 
        cur.close()
        return render_template('Add_products.html', products=products, Totals_Sales=Totals_Sales)
    else:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM product") 
        products = cur.fetchall() 
        cur.close()
        return render_template('Add_products.html', products=products, Totals_Sales=Totals_Sales)

@bp.route('/Update_Product/<int:id>', methods=['GET', 'POST'])
def Update_Product(id):
    cur = mysql.connection.cursor()
    if request.method == 'POST':
        prodName = request.form.get('name')
        prodDesc = request.form.get('description')
        prodPrice = request.form.get('price')
        prodInStock = request.form.get('quantity')
        cur.execute("UPDATE product SET prodName=%s, prodDesc=%s, prodPrice=%s, prodInStock=%s WHERE id=%s", (prodName, prodDesc, prodPrice, prodInStock, id))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('routes.add_product')) 
    cur.execute("SELECT * FROM product WHERE id=%s", [id])
    product = cur.fetchone()
    return render_template('Update_Product.html', product=product)

@bp.route('/delete/<int:id>')
def delete_product(id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM product WHERE id=%s", [id])
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('routes.add_product'))

from flask import render_template

@bp.route('/sale', methods=['GET', 'POST'])
def add_sale():
    if request.method == 'POST':
        product_id = int(request.form.get('product_id')) 
        quantity = int(request.form.get('quantity'))
        print('product_id:', product_id)
        print('quantity:', quantity)
        cur = mysql.connection.cursor()
        cur.execute("SELECT prodInStock FROM product WHERE id=%s", [product_id])
        product_in_stock = cur.fetchone()
        if product_in_stock is not None and product_in_stock[0] >= quantity:
            cur.execute("UPDATE product SET prodInStock=%s WHERE id=%s", (product_in_stock[0] - quantity, product_id))
            cur.execute("INSERT INTO sales (product_id, quantity, date) VALUES (%s, %s, %s)", (product_id, quantity, datetime.now().date()))
            mysql.connection.commit()
            cur.close()
            return jsonify({'message': 'Sale added successfully'})
        else:
            cur.close()
            return jsonify({'message': 'Not enough stock'}), 400
    else:
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM product")
        products = cur.fetchall()
        print(products) 
        cur.close()
        return render_template('add_sales.html', products=products)

@bp.route('/add')
def view_Add_Product():
    return render_template('Add_products.html')

@bp.route('/Sales_Product')
def view_Sales_Product():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM sales")
    sales_data = cur.fetchall()
    cur.close()
    return render_template('Sales_Product.html', Sales_Product=sales_data)


@bp.route('/sales_product', methods=['GET'])
def sales_product():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM product")  
    products = cur.fetchall()
    cur.close()
    return render_template('Add_sales.html', products=products)



@bp.route('/Totals_Sales')
def Totals_Sales():
    Totals_Sales = calculate_Totals_Sales()
    return render_template('Totals_Sales.html', Totals_Sales=Totals_Sales.items())
